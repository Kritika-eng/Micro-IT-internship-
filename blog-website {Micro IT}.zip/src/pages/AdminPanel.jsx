import React, { useState } from "react";

export default function AdminPanel() {
  const [allPosts, setAllPosts] = useState([
    { id: 1, title: "Welcome Post", author: "Admin" },
    { id: 2, title: "Another Post", author: "User123" },
  ]);

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Admin Panel</h2>
      <h3 className="text-lg font-semibold">All Blog Posts:</h3>
      {allPosts.map((post) => (
        <div key={post.id} className="border p-2 mb-2 rounded">
          <strong>{post.title}</strong> by {post.author}
        </div>
      ))}
    </div>
  );
}