import React, { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";

export default function Dashboard() {
  const { user } = useContext(AuthContext);
  const [posts, setPosts] = useState([]);
  const [title, setTitle] = useState("");

  const handleCreate = () => {
    const newPost = {
      id: Date.now(),
      author: user.name,
      title,
    };
    setPosts([...posts, newPost]);
    setTitle("");
  };

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold">Welcome, {user?.name}</h2>
      <div className="mt-4">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Write blog title..."
          className="p-2 border rounded w-full mb-2"
        />
        <button onClick={handleCreate} className="bg-blue-600 text-white p-2 rounded">
          Create Post
        </button>
      </div>

      <h3 className="text-xl mt-6 mb-2">Your Posts:</h3>
      {posts.map((post) => (
        <div key={post.id} className="border p-2 mb-2 rounded">
          <strong>{post.title}</strong> by {post.author}
        </div>
      ))}
    </div>
  );
}